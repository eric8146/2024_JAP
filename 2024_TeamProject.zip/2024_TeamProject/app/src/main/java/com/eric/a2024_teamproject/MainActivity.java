package com.eric.a2024_teamproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eric.a2024_teamproject.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private ArrayList<FoodItem> items;
    private FoodAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

        setContentView(R.layout.fragment_home);

        // 빈 데이터 리스트 생성
        items = new ArrayList<>();

        // 리사이클러뷰 설정
        RecyclerView recyclerView = findViewById(R.id.listview1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FoodAdapter(items, new FoodAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                showEditFoodDialog(position);
            }
        });
        recyclerView.setAdapter(adapter);

        // add_food 버튼 클릭 시 다이얼로그를 표시하여 항목을 추가하는 기능 구현
        Button addButton = findViewById(R.id.add_food);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddFoodDialog();
            }
        });

        // 검색 기능 구현
        androidx.appcompat.widget.SearchView searchView = findViewById(R.id.search);
        searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });
    }

    // 다이얼로그를 표시하여 사용자가 입력한 항목을 리스트뷰에 추가하는 메서드
    private void showAddFoodDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.adding_food, null);
        EditText nameEditText = dialogLayout.findViewById(R.id.food_name);
        EditText caloriesEditText = dialogLayout.findViewById(R.id.food_calories);
        EditText priceEditText = dialogLayout.findViewById(R.id.food_price);

        builder.setTitle("Add Food");
        builder.setMessage("Enter the details of the food item");
        builder.setView(dialogLayout);
        builder.setPositiveButton("OK", (dialog, which) -> {
            String name = nameEditText.getText().toString();
            int calories = Integer.parseInt(caloriesEditText.getText().toString());
            double price = Double.parseDouble(priceEditText.getText().toString());
            if (!name.isEmpty()) {
                // 사용자가 입력한 식품 정보를 리스트뷰에 추가
                items.add(new FoodItem(name, calories, price));
                adapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // 다이얼로그를 표시하여 사용자가 선택한 항목을 수정하는 메서드
    private void showEditFoodDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.adding_food, null);
        EditText nameEditText = dialogLayout.findViewById(R.id.food_name);
        EditText caloriesEditText = dialogLayout.findViewById(R.id.food_calories);
        EditText priceEditText = dialogLayout.findViewById(R.id.food_price);

        // 기존 내용을 EditText에 설정
        FoodItem foodItem = items.get(position);
        nameEditText.setText(foodItem.getName());
        caloriesEditText.setText(String.valueOf(foodItem.getCalories()));
        priceEditText.setText(String.valueOf(foodItem.getPrice()));

        builder.setTitle("Edit Food");
        builder.setMessage("Modify the details of the food item");
        builder.setView(dialogLayout);
        builder.setPositiveButton("OK", (dialog, which) -> {
            String name = nameEditText.getText().toString();
            int calories = Integer.parseInt(caloriesEditText.getText().toString());
            double price = Double.parseDouble(priceEditText.getText().toString());
            if (!name.isEmpty()) {
                // 사용자가 입력한 식품 정보를 업데이트
                items.set(position, new FoodItem(name, calories, price));
                adapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // 검색 기능을 수행하는 메서드
    private void filter(String text) {
        ArrayList<FoodItem> filteredList = new ArrayList<>();
        for (FoodItem item : items) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.updateList(filteredList);
    }
}
